#include<stdio.h>
#include<math.h>
int main()
{
    double radius1,radius2;
    double pi=3.1416;

    scanf("%lf %lf",&radius1,&radius2);

    double surface_area1=4*pi*radius1*radius1;
    double surface_area2=4*pi*radius2*radius2;
    double volume1=(4.0/3)*pi*radius1*radius1*radius1;
    double volume2=(4.0/3)*pi*radius2*radius2*radius2;
    double maximum_surface_area,maximum_volume;

    if(surface_area1>surface_area2)maximum_surface_area=surface_area1;
    else maximum_surface_area=surface_area2;

    if(volume1>volume2)maximum_volume=volume1;
    else maximum_volume=volume2;

    printf("%0.2lf %0.2lf\n",maximum_surface_area,maximum_volume);

    return 0;
}
