//ans to the question no:2
#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
    char a[1000];
    {
        printf("Enter a octal number: ");
        gets(a);
        int count=strlen(a)-1;
        int sum=0,x;
        for(int i=0; a[i]!='\0'; i++)
        {
            if(a[i]>='0' && a[i]<='7')
            {
                x=a[i]-48;
            }
            sum += x*pow(8,count);
            count--;
        }
        printf("The decimal number of %s is: %d\n",a,sum);
    }
    return 0;
}
