#include<stdio.h>
#include<stdlib.h>
struct node
{
    int d;
    struct node *next;
};
struct node *head = NULL;
struct node *current = NULL;
struct node *prev = NULL;
void insert(int d)
{
    struct node *link = (struct node*) malloc(sizeof(struct node));
    link->d = d;
    link->next = NULL;
    if(head==NULL)
    {
        head = link;
        return;
    }
    current = head;
    while(current->next!=NULL)
        current = current->next;
    current->next = link;
}
void display()
{
    struct node *ptr = head;
    while(ptr != NULL)
    {
        printf("%d \n",ptr->d);
        ptr = ptr->next;
    }
}
void remove_data(int d)
{
    int pos = 0;
    if(head==NULL)
    {
        printf("Linked List not initialized");
        return;
    }
    if(head->d == d)
    {
        if(head->next != NULL)
        {
            head = head->next;
            return;
        }
        else
        {
            head = NULL;
            printf("List is empty now");
            return;
        }
    }
    else if(head->d != d && head->next == NULL)
    {
        printf("%d is not found in the list\n", d);
        return;
    }
    current = head;
    while(current->next != NULL && current->d != d)
    {
        prev = current;
        current = current->next;
    }
    if(current->d == d)
    {
        prev->next = prev->next->next;
        free(current);
    }
    else
        printf("%d is not found in the list.\n", d);
}
int main()
{
    int a[1000], b, i, c;
    printf("Input the number of nodes: ");
    scanf("%d",&b);
    for(i=0; i<b; i++)
    {
        printf("Input data: " );
        scanf("%d", &a[i]);
        insert (a[i]);
    }
    printf("\nBefore Deletion the List is: \n");
    display();
    printf("\nWhich value do you want to delete?\n");
    scanf("%d",&c);
    remove_data(c);
    printf("\nAfter Deletion the List is: \n");
    display();
    return 0;
}
