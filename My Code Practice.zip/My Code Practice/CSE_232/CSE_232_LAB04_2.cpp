#include<iostream>
using namespace std;
int main()
{
    int i;
    char str1[50]="I am from Bangladesh",str2[50];

    cout<<"Name: Shrabani Das"<<endl<<"ID NO: 19203103078"<<endl<<"Intake: 45, Section: 02"<<endl;

    for(i=0; str1[i]!='\0'; i++)
    {
        str2[i]=str1[i];
    }
    str2[i]='\0';
    cout<<endl<<str2<<endl;
    return 0;
}
