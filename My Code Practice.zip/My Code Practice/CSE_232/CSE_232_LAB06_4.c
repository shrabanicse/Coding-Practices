#include<stdio.h>
#include<stdlib.h>
struct node
{
    int number;
    struct node *nptr;
}*stnode;
void createNodeList(int n);
void FirstNodeDeletion();
void displayList();
int main()
{
    int n,num,pos;
    //printf("\nName: Shrabani Das\nID NO: 19203103078\nIntake: 45\nSection: 02\n\n");
    printf("To delete the first node and display the data:\n");
    printf("Input the number of nodes: ");
    scanf("%d", &n);
    createNodeList(n);
    printf("Data entered in the list are: \n");
    displayList();
    FirstNodeDeletion();
    printf("\nData,after deletion of first node: \n");
    displayList();
    return 0;
}
void createNodeList(int n)
{
    struct node *fnNode, *tmp;
    int number, i;
    stnode = (struct node *)malloc(sizeof(struct node));
    if(stnode == NULL)
    {
        printf("Memory cannot be allocated!");
    }
    else
    {
        printf("Input data for node 1: ");
        scanf("%d", &number);
        stnode-> number = number;
        stnode-> nptr = NULL;
        tmp = stnode;
        for(i=2; i<=n; i++)
        {
            fnNode = (struct node *)malloc(sizeof(struct node));
            if(fnNode == NULL)
            {
                printf("Memory cannot be allocated!");
                break;
            }
            else
            {
                printf("Input data for node %d: ", i);
                scanf(" %d", &number);
                fnNode->number = number;
                fnNode->nptr = NULL;
                tmp->nptr = fnNode;
                tmp = tmp->nptr;
            }
        }
    }
}
void FirstNodeDeletion()
{
    struct node *toDelptr;
    if(stnode == NULL)
    {
        printf("There are no node in the list!");
    }
    else
    {
        toDelptr = stnode;
        stnode = stnode->nptr;
        printf("Data of node 1 which is being deleted is: %d\n", toDelptr->number);
        free(toDelptr);
    }
}
void displayList()
{
    struct node *tmp;
    if(stnode == NULL)
    {
        printf("No data found in the list!");
    }
    else
    {
        tmp = stnode;
        while(tmp != NULL)
        {
            printf("Data = %d\n", tmp->number);
            tmp = tmp->nptr;
        }
    }
}
