#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
}*stnode;
void initialize()
{
    stnode = NULL;
}
void insert(int number)
{
    struct node* newNode = (struct node*) malloc(sizeof(struct node));
    newNode->data  = number;
    newNode->next = stnode;
    stnode = newNode;
    printf("Inserted Node: %d\n", number);
}
void deleteNode(struct node *stnode, int number)
{
    struct node *current = stnode, *previous;
    if (stnode == NULL)
    {
        printf("Invalid node pointer!\n");
        return;
    }
    if (current->data == number)
    {
        stnode = current->next;
        free(current);
        return;
    }
    while (current != NULL && current->data != number)
    {
        previous = current;
        current = current->next;
    }
    if (current == NULL)
    {
        printf("%d not found in Linked List!\n");
        return;
    }
    previous->next = current->next;
    free(current);
}
void printLinkedList(struct node *nodePtr)
{
    while (nodePtr != NULL)
    {
        printf("%d", nodePtr->data);
        nodePtr = nodePtr->next;
        if(nodePtr != NULL)
            printf(" ");
    }
}
int main()
{
    initialize();
    insert(20);
    insert(40);
    insert(50);
    insert(90);
    printf("\nBefore Deletion of a Node:\n");
    printLinkedList(stnode);
    deleteNode(stnode, 40);
    printf("\n\nAfter Deletion of a Node:\n");
    printLinkedList(stnode);
    printf("\n\nName: Shrabani Das\nID NO: 19203103078\nIntake: 45\nSection: 02\n");
    return 0;
}
