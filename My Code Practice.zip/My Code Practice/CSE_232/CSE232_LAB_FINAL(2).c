#include<stdio.h>
#include<stdlib.h>
struct node
{
    int number;
    struct node *preptr;
    struct node *nextptr;
}*startnode, *endnode;
void DoubleLinkListcreation(int n);
void displayDoubleLinkList();
int main()
{
    int n;
    startnode = NULL;
    endnode = NULL;
    printf("To Implement the Double Link List and Display the Output:\n");
    printf("Input the number of nodes: ");
    scanf("%d", &n);
    DoubleLinkListcreation(n);
    displayDoubleLinkList();
    return 0;
}
void DoubleLinkListcreation(int n)
{
    int j, number;
    struct node *fNode;
    if(n >= 1)
    {
        startnode = (struct node*)malloc(sizeof(struct node));
        if(startnode != NULL)
        {
            printf("Input data for node 1: "); // assigning data in the first node
            scanf("%d", &number);
            startnode->number = number;
            startnode->preptr = NULL;
            startnode->nextptr = NULL;
            endnode = startnode;
// putting data for rest of the nodes
            for(j=2; j<=n; j++)
            {
                fNode = (struct node*)malloc(sizeof(struct node));
                if(fNode != NULL)
                {
                    printf("Input data for node %d: ", j);
                    scanf("%d", &number);
                    fNode->number = number;
                    fNode->preptr = endnode;    // new node is linking with the previous node
                    fNode->nextptr = NULL;
                    endnode->nextptr = fNode;   // previous node is linking with the new node
                    endnode = fNode;            // assign new node as last node
                }
                else
                {
                    printf("Memory cannot be allocated!");
                    break;
                }
            }
        }
        else
        {
            printf("Memory cannot be allocated!");
        }
    }
}
void displayDoubleLinkList()
{
    struct node *temp;
    int n = 1;
    if(startnode == NULL)
    {
        printf("No data found in the List yet!");
    }
    else
    {
        temp = startnode;
        printf("\nData entered in the list are:\n");

        while(temp != NULL)
        {
            printf("Node %d: %d\n", n, temp->number);
            n++;
            temp = temp->nextptr; // current pointer moves to the next node
        }
    }
}
