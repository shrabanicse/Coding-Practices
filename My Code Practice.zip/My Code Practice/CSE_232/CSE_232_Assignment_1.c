#include<stdio.h>
int stack[100],c,n,t,f,i;
void push(void);
void pop(void);
void display(void);
int main()
{
    //clrscr();
    t=-1;
    printf("\n Enter the size of STACK[MAX=100]:");
    scanf("%d",&n);
    printf("\n\t Stack Operations Using Array");
    printf("\n\t 1.PUSH\n\t 2.POP\n\t 3.DISPLAY\n\t 4.EXIT");
    do
    {
        printf("\n Enter the choice:");
        scanf("%d",&c);
        switch(c)
        {
            case 1:
            {
                push();
                break;
            }
            case 2:
            {
                pop();
                break;
            }
            case 3:
            {
                display();
                break;
            }
            case 4:
            {
                printf("\n\t EXIT POINT ");
                break;
            }
            default:
            {
                printf ("\n\t Please Enter a Valid Choice(1/2/3/4)");
            }

        }
    }
    while(c!=4);
    return 0;
}
void push()
{
    if(t>=n-1)
    {
        printf("\n\tSTACK is Over Flow");

    }
    else
    {
        printf(" Enter a value to be pushed:");
        scanf("%d",&f);
        t++;
        stack[t]=f;
    }
}
void pop()
{
    if(t<=-1)
    {
        printf("\n\t Stack is under flow");
    }
    else
    {
        printf("\n\t The popped elements is %d",stack[t]);
        t--;
    }
}
void display()
{
    if(t>=0)
    {
        printf("\n The elements in STACK \n");
        for(i=t; i>=0; i--)
            printf("\n%d",stack[i]);
        printf("\n Press Next Choice");
    }
    else
    {
        printf("\n The STACK is empty");
    }

}
