#include<stdio.h>
#include<stdlib.h>
struct node
{
    int number;
    struct node *nptr;
}*stnode;
void createNodeList(int n);
void LastNodeDeletion();
void displayList();
int main()
{
    int n,number;
    printf("\nName: Shrabani Das\nID NO: 19203103078\nIntake: 45\nSection: 02\n\n");
    printf("To delete the last node and display the data:\n");
    printf("Input the number of nodes: ");
    scanf("%d", &n);
    createNodeList(n);
    printf("Data entered in the list are: \n");
    displayList();
    LastNodeDeletion();
    printf("\nThe new list after deletion the last node is: \n");
    displayList();
    return 0;
}
void createNodeList(int n)
{
    struct node *fnNode, *tmp;
    int number, i;
    stnode = (struct node *)malloc(sizeof(struct node));
    if(stnode == NULL)
    {
        printf("Memory cannot be allocated!");
    }
    else
    {
        printf("Input data for node 1: ");
        scanf("%d", &number);
        stnode-> number = number;
        stnode-> nptr = NULL;
        tmp = stnode;
        for(i=2; i<=n; i++)
        {
            fnNode = (struct node *)malloc(sizeof(struct node));
            if(fnNode == NULL)
            {
                printf("Memory cannot be allocated!");
                break;
            }
            else
            {
                printf("Input data for node %d: ", i);
                scanf(" %d", &number);
                fnNode->number = number;
                fnNode->nptr = NULL;
                tmp->nptr = fnNode;
                tmp = tmp->nptr;
            }
        }
    }
}
void LastNodeDeletion()
{
    struct node *toDelLast, *preNode;
    if(stnode == NULL)
    {
        printf("There is no element in the list!");
    }
    else
    {
        toDelLast = stnode;
        preNode = stnode;
        while(toDelLast->nptr != NULL)
        {
            preNode = toDelLast;
            toDelLast = toDelLast->nptr;
        }
        if(toDelLast == stnode)
        {
            stnode = NULL;
        }
        else
        {
            preNode->nptr = NULL;
        }
        free(toDelLast);
    }
}
void displayList()
{
    struct node *tmp;
    if(stnode == NULL)
    {
        printf("No data found in the empty list!");
    }
    else
    {
        tmp = stnode;
        while(tmp != NULL)
        {
            printf("Data = %d\n", tmp->number);
            tmp = tmp->nptr;
        }
    }
}
