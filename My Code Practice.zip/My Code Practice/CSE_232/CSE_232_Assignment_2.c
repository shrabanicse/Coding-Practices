#include<stdio.h>
#define n 5
int main()
{
    int queue[n],c=1,f=0,r=0,i,j=1,x=n;
    printf("Queue using Array");
    printf("\n1.Insertion \n2.Deletion \n3.Display \n4.Exit");
    while(c)
    {
        printf("\nEnter the Choice:");
        scanf("%d",&c);
        switch(c)
        {
        case 1:
            if(r==x)
                printf("\nQueue is Full");
            else
            {
                printf("\nEnter no %d:",j++);
                scanf("%d",&queue[r++]);
            }
            break;
        case 2:
            if(f==r)
            {
                printf("\nQueue is empty");
            }
            else
            {
                printf("\nDeleted Element is %d",queue[f++]);
                x++;
            }
            break;
        case 3:
            printf("\nQueue Elements are:\n ");
            if(f==r)
                printf("\nQueue is Empty");
            else
            {
                for(i=f; i<r; i++)
                {
                    printf("%d",queue[i]);
                    printf("\n");
                }
                break;
            case 4:
                exit(0);
            default:
                printf("Wrong Choice: please see the options");
            }
        }
    }
    return 0;
}
