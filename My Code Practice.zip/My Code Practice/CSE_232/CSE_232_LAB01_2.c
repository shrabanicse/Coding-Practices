#include <stdio.h>
void display_output (int a[],int size)
{
    int f;
    printf("Resultant array:\n");
    for (f = 0; f < size - 1; f++)
    {
        printf("%d\n", a[f]);
    }
}
void delete_element(int a[],int size,int position)
{
    int f;
    for (f = position - 1; f < size- 1; f++) a[f] = a[f+1];
}
void input_element(int a[],int n)
{
    int f;
    printf("Enter %d elements:\n", n);
    for (f = 0; f < n; f++) scanf("%d", &a[f]);
}
int main()
{
    int a[100], position, f, n;
    printf("Enter number of elements in array:\n");
    scanf("%d", &n);
    input_element(a,n);
    printf("Enter the location where you wish to delete element:\n");
    scanf("%d", &position);
    if (position >= n+1) printf("Deletion not possible.\n");
    else
    {
        delete_element (a,n,position);
    }
    printf("Name: Shrabani Das\n");
    printf("Id: 19203103078\n");
    display_output (a,n);
    return 0;
}

