#include <stdio.h>
void display_output(int a[],int size)
{
    int f;
    printf("Resultant array is:\n");
    for(f=0; f<size+1; f++)
    {
        printf("%d ",a[f]);
    }
}
void insert_element (int a[],int size,int position,int value)
{
    int f;
    for(f=size-1; f>=position-1; f--)
    {
        a[f+1]=a[f];
    }
    a[position-1]=value;
}
void input_element(int a[],int n)
{
    int f;
    printf("Enter %d elements:\n", n);
    for(f=0; f<n; f++)
    {
        scanf("%d",&a[f]);
    }
}
int main()
{
    int position, f, n, value;
    int a[100];
    printf("Enter number of elements in array:\n");
    scanf("%d",&n);
    input_element(a,n);
    printf("Enter the location where you wish to insert an element:\n");
    scanf("%d", &position);
    printf("Enter the value to insert:\n");
    scanf("%d", &value);
    insert_element(a,n,position,value);
    printf("Name: Shrabani Das\n");
    printf("Id: 19203103078\n");
    display_output(a,n);
    return 0;
}
