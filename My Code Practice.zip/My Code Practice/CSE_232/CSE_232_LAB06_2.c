#include<stdio.h>
#include<stdlib.h>
struct node
{
    int number;
    struct node *nptr;
}*stnode;
void ClListcreation(int n);
void ClLinsertNodeAtBeginning(int number);
void ClLinsertNodeAtAny(int number, int position);
void displayClList(int a);
int main()
{
    int n,number1,a,d;
    stnode = NULL;
    printf("\nName: Shrabani Das\nID NO: 19203103078\nIntake: 45\nSection: 02\n\n");
    printf("To insert a node to a desired place and display the data:\n");
    printf("Input the number of nodes: ");
    scanf("%d", &n);
    ClListcreation(n);
    a=1;
    displayClList(a);
    printf("\nInput the position to insert a new node: ");
    scanf("%d", &d);
    printf("Input data for the position %d: ", d);
    scanf("%d", &number1);
    ClLinsertNodeAtAny(number1,d);
    a=2;
    displayClList(a);
    return 0;
}
void ClListcreation(int n)
{
    int i, number;
    struct node *preptr, *newnode;

    if(n >= 1)
    {
        stnode = (struct node *)malloc(sizeof(struct node));
        printf("Input data for node 1: ");
        scanf("%d", &number);
        stnode->number = number;
        stnode->nptr = NULL;
        preptr = stnode;
        for(i=2; i<=n; i++)
        {
            newnode = (struct node *)malloc(sizeof(struct node));
            printf("Input data for node %d: ", i);
            scanf("%d", &number);
            newnode->number = number;
            newnode->nptr = NULL;
            preptr->nptr = newnode;
            preptr = newnode;
        }
        preptr->nptr = stnode;
    }
}
void ClLinsertNodeAtBeginning(int number)
{
    struct node *newnode, *curNode;

    if(stnode == NULL)
    {
        printf("No data found in the List yet!");
    }
    else
    {
        newnode = (struct node *)malloc(sizeof(struct node));
        newnode->number = number;
        newnode->nptr = stnode;
        curNode = stnode;
        while(curNode->nptr != stnode)
        {
            curNode = curNode->nptr;
        }
        curNode->nptr = newnode;
        stnode = newnode;
    }
}
void ClLinsertNodeAtAny(int number, int position)
{
    struct node *newnode, *curNode;
    int i;

    if(stnode == NULL)
    {
        printf("No data found in the List yet!");
    }
    else if(position == 1)
    {
        ClLinsertNodeAtBeginning(number);
    }
    else
    {
        newnode = (struct node *)malloc(sizeof(struct node));
        newnode->number = number;
        curNode = stnode;
        for(i=2; i<=position-1; i++)
        {
            curNode = curNode->nptr;
        }
        newnode->nptr = curNode->nptr;
        curNode->nptr = newnode;
    }
}
void displayClList(int m)
{
    struct node *tmp;
    int n = 1;

    if(stnode == NULL)
    {
        printf("No data found in the List yet!");
    }
    else
    {
        tmp = stnode;
        if (m==1)
        {
            printf("Data entered in the list are:\n");
        }
        else
        {
            printf("After insertion the new list are:\n");
        }
        do
        {
            printf("Data %d = %d\n", n, tmp->number);

            tmp = tmp->nptr;
            n++;
        }
        while(tmp != stnode);
    }
}
