#include<stdio.h>
int main()
{
    int n[100], i, number, minimum;
    printf("Enter the number of elements :");
    scanf("%d", &number);
    for (i = 0; i < number; i++)
        scanf("%d", &n[i]);
    minimum = n[0];
    for (i = 0; i < number; i++)
    {
        if (n[i] < minimum)
        {
            minimum = n[i];
        }
    }
    printf("Minimum Number : %d", minimum);
    return 0;
}
