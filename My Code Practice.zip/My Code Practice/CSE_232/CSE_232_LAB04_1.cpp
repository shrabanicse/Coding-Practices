#include<iostream>
using namespace std;
int main()
{
    int i,j,length=0;
    char str1[50]="Shrabani Das";
    char str2[50]="Chakaria, Cox's Bazar";

    cout<<"Name: Shrabani Das"<<endl<<"ID NO: 19203103078"<<endl<<"Intake: 45, Section: 02"<<endl;

    for(i=0; str1[i]!='\0'; i++)
    {
        length++;
    }
    for(j=0; str2[j]!='\0'; j++)
    {
        str1[i]=str2[j];
        i++;
    }
    str1[i]='\0';
    cout<<endl<<"After concating: "<<str1<<endl;
    return 0;
}
