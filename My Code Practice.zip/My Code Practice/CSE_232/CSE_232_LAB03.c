#include <stdio.h>
int main()
{
    int n,i,f,left,middle,right,array[1000];
    printf("Name: Shrabani Das\n");
    printf("ID NO: 19203103078\n");

    printf("Enter the number of elements:\n");
    scanf("%d", &n);
    printf("Enter %d integers:\n",n);
    for (i=0; i<n; i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Enter the value to find index number:\n");
    scanf("%d", &f);
    left=0;
    right=n-1;
    middle=(left+right)/2;
    while (left<=right)
    {
        if (f>array[middle])//f is on the right side
            left=middle+1;
        else if (f==array[middle])//return middle
        {
            printf("'%d' found at %d number index.\n", f, middle);
            break;
        }
        else//f is on the left side
            right=middle-1;
        middle=(left + right)/2;
    }
    if (left>right)
        printf("%d isn't present here!\n",f);

    return 0;
}
