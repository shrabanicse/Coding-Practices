#include<stdio.h>
void func(int *p,int *q)//changed q as a variable to pointer q in whole function.
{
    *p= *p + *q;
     *q= *q + 5;
    *p= *p+ *q;
}
int *value()
{
    int x=10,y=5,*ptr;//data type of x,y,*ptr changed integer to character.

    ptr=&y;//removed pointer sign from ptr.
    x=*ptr+ --x;//added pointer before ptr.
    func(&x,&y);//added &sign before x and y and semicolon after the statement.
    printf("%d %d\n",x,*ptr); //fixed the format specifier of x and ptr and added pointer before ptr.
    return ptr;
}
int main()
{
    int i,j,*k;//declared k as a pointer variable.
    k=value();
    printf("the result is: %d\n",*k--);//changed format specifier and printed value of pointer k.
    return 0;
}
