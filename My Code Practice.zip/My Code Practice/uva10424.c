#include<stdio.h>
#include<string.h>
int main()
{
    char a[30],b[30];
    int i,j,add,add1,val,d;
    double result,sum,sum1;
    while(gets(a))
    {
        gets(b);
        add=0;
        sum=0;
        sum1=0;
        for(i=0; i<strlen(a); i++)
        {
            if(a[i]>='A' && a[i]<='Z')
            {
                val=a[i]-64;
            }
            else if(a[i]>='a' && a[i]<='z')
            {
                val=a[i]-96;
            }
            else
            {
                val=0;
            }
            add=add+val;
        }
        while(add!=0)
        {
            sum=0;
            while(add!=0)
            {
                d=add%10;
                add=add/10;
                sum=sum+d;
            }

            if(sum>9)
                add=sum;
        }
        add1=0;
        for(i=0; i<strlen(b); i++)
        {
            if(b[i]>='A' && b[i]<='Z')
            {
                val=b[i]-64;
            }
            else if(b[i]>='a' && b[i]<='z')
            {
                val=b[i]-96;
            }
            else
            {
                val=0;
            }
            add1=add1+val;
        }

        while(add1!=0)
        {
            sum1=0;
            while(add1!=0)
            {
                d=add1%10;
                add1=add1/10;
                sum1=sum1+d;
            }

            if(sum1>9)
                add1=sum1;
        }
        if(sum>sum1)
            result=(sum1*100)/sum;
        else
            result=(sum*100)/sum1;
        printf("%0.2lf %%\n",result);
    }
    return 0;
}
