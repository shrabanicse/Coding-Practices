#include<stdio.h>
int main()
{
    int n,i,j;
    printf("Enter n:\n");
    scanf("%d",&n);
    for(i=n; i>=0; i--)
    {
        for(j=i; j>0; j--)

        {
            printf("*");
        }
        if(i>1)
        printf("\n");
    }
    return 0;
}
