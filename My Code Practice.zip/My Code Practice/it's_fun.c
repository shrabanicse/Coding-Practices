#include<stdio.h>
int main()
{
    long long int year;
    while (scanf("%lld",&year)!=EOF)
    {
        if(year%4==0 && year%100!=0 && year%15==0)
        {
            printf("This is leap year.\n");
            printf("This is huluculu festival year.\n");
        }
        else if(year%400==0 && year%15==0)
        {
            printf("This is leap year.\n");
            printf("This is huluculu festival year.\n");
        }

        else if(year%15==0)
            printf("This is huluculu festival year.\n");

        else if(year%4==0 && year%100!=0 && year%15==0 && year%55==0)
        {
            printf("This is leap year.\n");
            printf("This is huluculu festival year.\n");
            printf("This is bulukulu festival year.\n");
        }

        else if(year%400==0 && year%15==0 && year%55==0)
        {
            printf("This is leap year.\n");
            printf("This is huluculu festival year.\n");
            printf("This is bulukulu festival year.\n");
        }

        else if(year%4==0 && year%100!=0 && year%55==0)
        {
            printf("This is leap year.\n");
            printf("This is bulukulu festival year.\n");
        }

        else if(year%400==0 && year%55==0)
        {
            printf("This is leap year.\n");
            printf("This is bulukulu festival year.\n");
        }

        else if(year%4==0 && year%100!=0)
            printf("This is leap year.\n");

        else if(year%400==0)
            printf("This is leap year.\n");

        else
            printf("This is an ordinary year.\n");

        printf("\n");
    }
    return 0;


}
