#include<stdio.h>
int main()
{
    int n,t,i;
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        scanf("%d",&t);
        {
            if(t==1)
            {
                printf("Welcome to the BUBT IUPC\n");
            }
            if(t==2)
            {
                printf("Thank You\n");
            }
        }

    }

    return 0;
}
