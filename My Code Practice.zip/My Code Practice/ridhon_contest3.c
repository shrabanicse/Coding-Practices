#include<stdio.h>
#include<math.h>
int main ()
{
    int t,i;
    double a,m,r;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%lf",&r);
        a=2*acos (0.0)*r*r;
        m=(r*2)*(r*2);
        printf("Case %d: %.2lf\n",i+1,m-a);

    }
    return 0;
}
