#include<stdio.h>
int main()
{
    int first[10][10],r1,c1,i,j;
    printf("Enter rows and columns for matrix: ");
    scanf("%d %d",&r1,&c1);
    //taking input for matrix
    printf("Enter elements for matrix:\n");
    for(i=0; i<r1; i++)
    {
        for(j=0; j<c1; j++)
        {
            printf("Index[%d][%d] = ",i,j);
            scanf("%d",&first[i][j]);
        }
    }
    //printing matrix
    printf("Matrix =\n");
    for(i=0; i<r1; i++)
    {
        printf("\t");
        for(j=0; j<c1; j++)
            printf("%d ",first[i][j]);
        printf("\n");
    }
    return 0;
}

