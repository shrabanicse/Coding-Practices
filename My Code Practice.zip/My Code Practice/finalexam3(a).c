#include<stdio.h>
#include<math.h>
int main()
{
    int i,sum=0,d;
    double t[12];
    for(i=0; i<12; i++)
        scanf("%lf",&t[i]);
    for(i=0; i<12; i++)
    {
        d=(int)t[i];
        if( (t[i]!= d) )
            t[i]=-1;
        else if(t[i]>6 && t[i]<22)
            t[i]=1;
    }
    for(i=11; i>=0; i--)
    {
        sum=sum+t[i];
        printf("%.0lf ",t[i]);
    }
    printf("\n%d",sum);
    return 0;
}
