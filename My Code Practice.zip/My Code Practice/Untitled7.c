#include <stdio.h>
int main()
{
    long long int a, b, c, d, e, f;
    long long int A[10000], r;
    int n, caseno = 0, cases;
    scanf("%d", &cases);
    while( cases-- )
    {
        scanf("%lld %lld %lld %lld %lld %lld %d", &A[0], &A[1], &A[2], &A[3], &A[4], &A[5], &n);
        for(r=6; r<=n; r++)
            A[r]=(A[r-1]+A[r-2]+A[r-3]+A[r-4]+A[r-5]+A[r-6])%10000007;
        printf("Case %d: %lld\n", ++caseno, A[n]  % 10000007);
    }
    return 0;
}
