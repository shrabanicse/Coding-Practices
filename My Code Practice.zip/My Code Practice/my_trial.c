#include<stdio.h>
int main()
{
    printf("\nName: Shrabani Das\nID NO: 19203103078\nIntake: 45\nSection: 02\n");

return 0;
}
