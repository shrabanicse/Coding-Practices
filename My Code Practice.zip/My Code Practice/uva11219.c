#include<stdio.h>
int main()
{

    int i,t,y,year1,year2,month1,month2,day1,day2;

    scanf("%d",&t);

    i=1;

    while(i<=t)
    {

        scanf("%d/%d/%d",&day1,&month1,&year1);
        scanf("%d/%d/%d",&day2,&month2,&year2);

        y=(year1-year2);

        if(month1<month2)
            y--;

        else if(month1==month2)
        {
            if(day1<day2)
                y--;
        }

        if(y<0)
            printf("Case #%d: Invalid birth date\n", i );
        else if(y>130)
            printf("Case #%d: Check birth date\n", i);
        else
            printf("Case #%d: %d\n",i,y);

        i++;

    }

    return 0;

}
