#include <iostream>
#include <string.h>
using namespace std;

template <class TypeName>

// function using the template
void printArray(TypeName* arr)
{
    for (int i = 0; i < 10; i++) {
        cout << *arr << " ";
        ++arr; // pointing to next element
    }
    cout << endl;
}
template<typename T>
 void sort(Typename list[])
 {
 for (int i = 0; i < 10; i++) {
 // Find the minimum in the list[i..listSize-1]
 T currentMin = list[i];
int currentMinIndex = i;
 for (int j = i + 1; j < listSize; j++)
{ if (currentMin > list[j])
 {
currentMin = list[j];
currentMinIndex = j;}} // Swap list[i] with list[currentMinIndex] if necessary;
 if (currentMinIndex != i)
{
list[currentMinIndex] = list[i];
list[i] = currentMin;}}}
template<typename T>
void printArray(const T list[], int listSize)
{for (int i = 0; i < listSize; i++)
{ cout << list[i] << " ";
}
 cout << endl;
}

// main code/ main function
int main()
{
    // declaring character array
    char chrArr[] = "abcdefghij";
    //declaring integer array
    int numArr[] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

    //printing array elements
    cout << "chrArr: ";
    printArray(chrArr);

    cout << "numArr: ";
    printArray(numArr);
    cout << "nArr: ";

    double nArr[] = {1.20, 20.4, 3.45, 44.7, 50.32, 60.45, 70.1, 80.08, 90.4, 100.4};
    printArray(nArr);


    return 0;
}
