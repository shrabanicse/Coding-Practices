#include<stdio.h>
int main()
{
    int a[110],n,t,i,j,k;
    scanf("%d",&n);
    for(j=0;j<n;j++)
        {
            scanf("%d",&a[j]);
        }
for (i = 0; i < n; i++)                     //Loop for ascending ordering
	{
		for (j = 0; j < n; j++)             //Loop for comparing other values
		{
			if (a[j] > a[i])                //Comparing other array elements
			{
				int tmp = a[i];         //Using temporary variable for storing last value
				a[i] = a[j];            //replacing value
				a[j] = tmp;             //storing last value
			}
		}
	}
	printf("\nAscending : ");                     //Printing message
	for (i = 0; i < n; i++)                     //Loop for printing array data after sorting
	{
		printf(" %d ", a[i]);
	}
	return 0;
}
