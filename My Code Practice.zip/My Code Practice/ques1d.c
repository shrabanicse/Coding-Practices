#include<stdio.h>
int main()
{
    long int m,n;
    m=5;
    n=6;
    m++;
    if(m++==n)
    {
        printf("Equal\n");
    }
    else
    {
        printf("Not Equal\n");
    }
    printf("m=%ld m= %ld", m,--n);
    return 0;
}
