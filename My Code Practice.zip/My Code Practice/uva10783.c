#include<stdio.h>
int main()
{
    int a,b,t,i,l,sum=0;
    while(scanf("%d",&t)!=EOF)
    {
        for(i=1;l<=t,l=++)
        {
            scanf("%d%d",&a,&b);
        {
            if(a>b){
                int temp=a;
                b=temp;
            }
            for(i=a;i<=b;i=i+1)
            {
}
        }
        }
    }
}
