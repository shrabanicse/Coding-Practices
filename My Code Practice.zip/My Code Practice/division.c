#include<stdio.h>
int main()
{
    int a,b;
    printf("Input two numbers:\n");
    scanf("%d%d",&a,&b);
    int div=a/b;
    printf("The quotient is %d\n",div);
    return 0;
}

