#include<stdio.h>
main()
{
    int a,b;
    printf("Input two numbers:\n");
    scanf("%d%d",&a,&b);
    int sub=abs(a-b);
    printf("Subtraction from %d to %d is %d\n",a,b,sub);
    return 0;
}
