#include<stdio.h>
int main()
{
    int a,b;
    double c,d,e;
    scanf("%d%d%lf",&a,&b,&c);
    d=b*c;
    scanf("%d%d%lf",&a,&b,&c);
    e=d+(b*c);
    printf("VALOR A PAGAR: R$ %.2lf\n",e);
    return 0;
}
