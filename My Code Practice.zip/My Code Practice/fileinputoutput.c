#include <stdio.h>
int main()
{

  //  FILE *fp;  // File pointer
    //int *ptr;
    FILE *fp;
   // char arr[10000];
     int a[1000];
     char arr[1000];
    fp= fopen("inputs.txt", "r");
    if(fp== NULL)
    {
        printf("could not open the file\n");
    }
    int v;
    int sum=0;
    int idx=0;
  /*  while(fscanf( fp, "%d", &a[idx])!= EOF)
    {
        //sum+= a
        //a[idx]= v;
       // sum+= v;
        //idx++;
        //printf("%s\n", arr);
            //
               // printf("%d\n", a[idx]);
            //idx++;
          //  sum+= a[idx]
    idx++;
    }
    for(int i=0; i<idx; i++)
    {
        printf("%d ", a[i]);
        sum+= a[i];
    }
    printf("sum= %d", sum);
    fclose(fp);
    */
    while(fgets( arr, 1000, fp)!= NULL)
    {
        printf("%s", arr);
    }
     fclose(fp);


   /* char arr[50];
    int v; //String
    printf( "Opening the file in read mode: \n" ) ;
    fp = fopen("input2.txt", "r");
    if ( fp == NULL )
    {
        printf( "Could not open the file\n" );
    }
    printf( "Reading the file: \n" );
    while( fgets ( arr, 50, fp ) != NULL )
    {
        printf( "%s", arr);
    }

    printf("Closing the file \n") ;
    fclose(fp) ; */
return 0;
}



#include<stdio.h>
int main()
{
    FILE *fp;
    char ch;
    fp = fopen("output1.txt", "w");
   // printf("Enter data...");
   int cnt=0;
    while( (scanf("%c", &ch)) != EOF) {
        putc(ch, fp);
       // if(ch=='0') break;
       //fprintf(fp, ch);
       cnt++;
       if(cnt==15) break;
       // puts()
    }
    fclose(fp);
    //fp = fopen("one.txt", "r");

   /* while( (ch = getc(fp))!= EOF)
          {
              printf("%c",ch);
          } */


    // closing the file pointer
 //   fclose(fp);

    return 0;
}
