#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
    char sms[100];
    int i,t,a;
    scanf("%d",&t);
    int count=1,j;
    getchar();

    for( j=0; j<t; j++)
    {
        gets(sms);
        int a=0;
        for(i=0; sms[i]!='\0'; i++)
        {

            if(sms[i]=='a' || sms[i]=='d' || sms[i]=='g' || sms[i]=='j' || sms[i]=='m' || sms[i]=='p' || sms[i]=='t' || sms[i]=='w')
            {
                a=a+1;
            }
            else if(sms[i]=='b' || sms[i]=='e' || sms[i]=='h' || sms[i]=='k' || sms[i]=='n' || sms[i]=='q' || sms[i]=='u' || sms[i]=='x')
            {
                a=a+2;
            }
            else if(sms[i]=='c' || sms[i]=='f' || sms[i]=='i' || sms[i]=='l' || sms[i]=='o' || sms[i]=='r' || sms[i]=='v' || sms[i]=='y')
            {
                a=a+3;
            }
            else if(sms[i]=='s' || sms[i]=='z')
            {
                a=a+4;
            }
            else if(sms[i]==' ' || sms[i]==' ')
            {
                a=a+1;
            }
        }
        printf("Case #%d: %d\n",count,a);
        count++;
    }
    return 0;
}
