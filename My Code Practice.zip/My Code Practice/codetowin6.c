#include<stdio.h>
int main()
{
    int t,i,n,j,a,b,c,d;
    scanf("%d",&t);
    for(i=0; i<t; i++)
    {
        c=d=0;
        scanf("%d",&n);
        for(j=0; j<n; j++)
        {
            scanf("%d%d",&a,&b);
            if(a>b)
                c++;
            else if(b>a)
                d++;
            else
                continue;
        }
        if(c>d)
            printf("Harry will marry Granger\n");
        else if(d>c)
            printf("Ron will marry Granger\n");
        else
            printf("It is a Draw\n");
    }
    return 0;
}
