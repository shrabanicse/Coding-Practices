#include<stdio.h>
int main()
{
    long int a,i,n,j;
    scanf("%ld",&a);
    for(i=0;i<a;i++)
    {
        scanf("%ld",&n);
        if(n==0)
            printf("invalid");
        else
        {
            for(j=1;j<=n;j++)
            {
                if(n==j)
                printf("%ld",j);
            else
                printf("%ld ",j);
            }
        }
    }
    return 0;
}
