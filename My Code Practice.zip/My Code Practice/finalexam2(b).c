#include<stdio.h>
struct University
{
    char university_name[100];
    int num_of_faculties;
    char location[110];
    char email[100];
    char student_id[100];
};
int main()
{
    struct University std[100];
    for(int i=0; i<5; i++)
    {
        gets(std[i].university_name);
        scanf("%d",&std[i].num_of_faculties);
        getchar();
        gets(std[i].location);
        gets(std[i].email);
        gets(std[i].student_id);
    }
    for(int j=0; j<5; j++)
    {
        printf("Name of the University: ");
        puts(std[j].university_name);
        printf("Number of Faculties: %d\n", std[j].num_of_faculties);
        printf("Location: ");
        puts(std[j].location);
        printf("Email Address: ");
        puts(std[j].email);
        printf("Student's ID: ");
        puts(std[j].student_id);
    }
    return 0;
}
