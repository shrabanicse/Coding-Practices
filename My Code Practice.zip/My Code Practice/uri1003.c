#include<stdio.h>
int main()
{
    int A,B,SUM;
    scanf("%d %d",&A,&B);
    SUM=A+B;
    printf("SOMA = %d\n",SUM);
    return 0;
}
