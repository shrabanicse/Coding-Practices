#include    <stdio.h>

int         main()

{

            int a,b,sum;

              a=50;
              b=60;

              sum=a+b;

            printf ("Sum of %d and %d is %d", a,b,sum);

            return 0;

}
