#include<stdio.h>
int main()
{
    double n;
    printf("Enter a number:\n");
    scanf("%lf",&n);
    int temp;
    temp=(int)n;
    if(n<=0){
        printf("It is a tie\n");
    }
    else if(temp==n){
        printf("Shrabani wins\n");
    }
    else{
        printf("My friend win\n");
    }

    return 0;
}
