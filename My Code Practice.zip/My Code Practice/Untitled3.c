#include<stdio.h>
int main()
{
    long long int i=0,j=0,year;
    while(scanf("%lld",&year)!=EOF)
    {
        if(year%400==0)
        {
            printf("This is leap year.\n");
            i=1,j=1;
        }
        else if(year%4==0 && year%100!=0)
        {
            printf("This is leap year.\n");
            i=1,j=1;
        }
        if(year%15==0)
        {
            printf("This is huluculu festival year.\n");
            i=1;
        }
        if(year%55==0 && j==1)
        {
            printf("This is bulukulu festival year.\n");
            i=1;
        }
        if(i!=1)
        {
            printf("This is an ordinary year.\n");
        }
        printf("\n");
        i=0,j=0;
    }
    return 0;
}
