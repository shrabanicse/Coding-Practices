#include <stdio.h>
#include <string.h>
int main()
{
    char t[1000];
    int i,a,b,j,len;
    while(scanf("%s",&t)!=EOF)
    {
        a=0;
        b=0;
        len=strlen(t);
        for(j=0; j<len; j++)
        {
            if(t[j]==t[len-j-1])
            {
                a++;
            }
        }
        for(i=0; i<len; i++)
        {
            if((t[i]=='A' && t[len-i-1]=='A')||(t[i]=='E' && t[len-i-1]=='3')||(t[i]=='3' && t[len-i-1]=='E')||
                    (t[i]=='H' && t[len-i-1]=='H')||(t[i]=='I' && t[len-i-1]=='I')||(t[i]=='J' && t[len-i-1]=='L')||
                    (t[i]=='L' && t[len-i-1]=='J')||(t[i]=='M' && t[len-i-1]=='M')||(t[i]=='O' && t[len-i-1]=='O')||
                    (t[i]=='2' && t[len-i-1]=='S')||(t[i]=='T' && t[len-i-1]=='T')||(t[i]=='U' && t[len-i-1]=='U')||
                    (t[i]=='V' && t[len-i-1]=='V')||(t[i]=='W' && t[len-i-1]=='W')||(t[i]=='X' && t[len-i-1]=='X')||
                    (t[i]=='Y' && t[len-i-1]=='Y')||(t[i]=='Z' && t[len-i-1]=='5')||(t[i]=='5' && t[len-i-1]=='Z')||
                    (t[i]=='1' && t[len-i-1]=='1')||(t[i]=='S' && t[len-i-1]=='2')||(t[i]=='8' && t[len-i-1]=='8'))
                b++;
        }
        if(a==len && len!=b)
            printf("This is a regular palindrome.\n");
        else if(a!=len && len==b)
            printf("This is a mirrored string.\n");
        else if(a!=len && len!=b)
            printf("This is not a palindrome\n");
    }
    return 0;
}
