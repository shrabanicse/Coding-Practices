#include<stdio.h>
int main()
{
    int t,i,f;
    scanf("%d",&t);
    for(i=0; i<t; i++)
    {
        scanf("%d",&f);
        if(f%10==0)
        {
            printf("YES\n");
        }
        else
        {
            printf("NO\n");
        }
    }
    return 0;
}
