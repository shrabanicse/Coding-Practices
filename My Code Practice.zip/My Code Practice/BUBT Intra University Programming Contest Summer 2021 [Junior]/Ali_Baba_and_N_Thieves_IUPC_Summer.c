#include<stdio.h>
int main()
{
    long long int T,N,W,M,i,F,G,H;
    scanf("%lld",&T);
    for(i=0; i<T; i++)
    {
        scanf("%lld%lld%lld",&N, &W, &M);
        F=M/W;
        G=M%W;
        N=N+1;
        if(G!=0)
        {
            F=F+1;
        }
        H=F-N;
        if(H<=0)
        {
            H=0;
        }
        printf("%lld\n",H);
    }
    return 0;
}
