#include<stdio.h>
int main()
{
    printf("BUBT Intra University Programming Contest Summer 2021\n");
    return 0;
}
