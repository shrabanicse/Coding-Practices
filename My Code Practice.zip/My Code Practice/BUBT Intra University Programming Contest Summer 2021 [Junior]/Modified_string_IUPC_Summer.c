#include<stdio.h>
#include<string.h>
int main()
{
    char a[5000],c[100];
    int t,b,i,j;
    scanf("%d",&t);
    gets(c);
    for(j=0; j<t; j++)
    {
        gets(a);
        b=strlen(a);
        for(i=0; i<b; i++)
        {
            if(a[i]=='a' || a[i]=='A')
            {
                printf("A##");
            }
            else if(a[i]=='e' || a[i]=='E')
            {
                printf("E##");
            }
            else if(a[i]=='k' || a[i]=='K')
            {
                printf("K##");
            }
            else if(a[i]=='o' || a[i]=='O')
            {
                printf("O##");
            }
            else if(a[i]=='u' || a[i]=='U')
            {
                printf("U##");
            }
            else
                continue;
        }
        printf("\n");
    }
    return 0;
}
