#include<stdio.h>
int main()
{
    long long int n,t,p,k,j,m=0;
    scanf("%lld%lld%lld", &n,&p,&k);
    for(j=0; j<n; j++)
    {
        scanf("%lld", &t);
        if(p>=t)
        {
            p=p+t;
        }
        else
        {
            m++;
        }
    }
    if(m<=k)
        printf("YES\n");
    else
        printf("NO\n");
    return 0;
}
