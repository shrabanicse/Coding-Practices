#include<stdio.h>
int main()
{
    int f;
    scanf("%d",&f);
    if(f==0)
    {
        printf("You are not allowed to enter university\n");
    }
    if(f==1)
    {
        printf("You are only allowed to attend examinations\n");
    }
    if(f==2)
    {
        printf("You are allowed to attend all activities offline\n");
    }
    return 0;
}
