#include<stdio.h>
int main()
{
    int N;
    N=(365+14+30+31+30+31+31+30+31+30+15);
    if(N%2==0)
    {
        int a;
        a=N/2;
        printf("%d\n",a);
    }
    else
    {
        int b;
        b=N*2;
        printf("%d\n",b);
    }
    return 0;
}
