#include<stdio.h>
int main()
{
	printf("Tourist\n");
	return 0;
}
