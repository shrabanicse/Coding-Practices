#include<stdio.h>
int main()
{
    int a[110],n,t,i,j,k,b[100],m;
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        scanf("%d",&t);
        int sum1=0,sum2=0;
        for(j=0; j<t; j++)
        {
            scanf("%d",&a[j]);
        }
        for(k=0; k<t; k++)
        {
            if(k%2==0)
                sum1=sum1+a[k];
            else
                sum2=sum2+a[k];
        }
        m=0;
        if(sum1>sum2)
        {
            for(j=0; j<t; j+=2)
            {
                b[m]=a[j];
                m++;
            }
            printf("Case %d: Myself\n",i+1);
        }

        else
        {
            for(j=1; j<t; j+=2)
            {

                b[m]=a[j];
                m++;
            }
            printf("Case %d: My Sister\n",i+1);
        }
        for (int r = 0; r < m; r++)
        {
            for (j = 0; j < m; j++)
            {
                if (b[j] > b[r])
                {
                    int temp = b[r];
                    b[r] = b[j];
                    b[j] = temp;
                }
            }
        }

        for (j = 0; j < m; j++)
        {
            printf("%d ", b[j]);
        }
        printf("\n");

    }

    return 0;
}
