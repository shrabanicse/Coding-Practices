//ans to the question no:1
#include<stdio.h>
#include<string.h>
int main()
{
    char a[1000],c[1000];
    int b,i,j=0,count=0;
    gets(a);
    b=strlen(a);
    for(i=0; i<b; i++)
    {
        if(a[i]=='a' || a[i]=='e' || a[i]=='i' || a[i]=='o' || a[i]=='u' || a[i]=='@' || a[i]=='#' || a[i]=='%' || a[i]=='*' || a[i]=='-' || a[i]=='+' || a[i]=='&')
        {
            c[j]=a[i];
            j++;
        }
        if(a[i]==' ' && count==0)
        {
            c[j]=a[i];
            j++;
            count=1;
        }
    }
    c[j]='\0';
    puts(c);
    return 0;
}
