#include<stdio.h>
int main()
{
    int t,n,H,M,h,c,m,cases=0;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d:%d",&n,&H,&M);
        int mn=0xfffffff;
        H = H*60+M;
        while(n--)
        {
            scanf("%d:%d %d",&h,&m,&c);
            h = h*60+m;
            if(h<H)
                h+=1440;
                h+=c;
            if(mn>h)
                mn=h;
        }
        printf("Case %d: %d\n",++cases,mn-H);
    }
    return 0;
}
