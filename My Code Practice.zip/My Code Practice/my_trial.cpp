#include<iostream>
using namespace std;
int main()

{
    //cout<<"\nName: Shrabani Das\nID NO: 19203103078\nIntake: 45\nSection: 02\n";
    cout<<endl<<"Name: Shrabani Das"<<endl<<"ID NO: 19203103078"<<endl<<"Intake: 45"<<endl<<"Section: 02"<<endl;
    return 0;
}
