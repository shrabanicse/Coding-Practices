#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
    char a[11000];
    int n,t,y,d,i,j;
    scanf("%d\n",&n);
    for(t=0; t<n; t++)
    {
        gets(a);
        y=strlen(a);
        d=sqrt(y);
        double b=sqrt(y);
        if(b-d>0)
        {
            printf("INVALID\n");
        }
        else
        {
            for(i=0; i<d; i++)
            {
                for(j=i; j<y; j+=d)
                {
                    printf("%c",a[j]);
                }
            }
            printf("\n");
        }
    }
    return 0;
}
