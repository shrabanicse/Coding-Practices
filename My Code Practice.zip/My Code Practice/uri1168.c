#include<stdio.h>
#include<string.h>
int main()
{
    int n;
    char a[1000];
    scanf("%d",&n);
    while(n--)
    {
        scanf("%s",a);
        int i=0;
        int j=0;
        while(a[i] != '\0')
        {
            switch(a[i])
            {
            case('1'):
                j+=2;
                break;
            case('2'):
                j+=5;
                break;
            case('3'):
                j+=5;
                break;
            case('4'):
                j+=4;
                break;
            case('5'):
                j+=5;
                break;
            case('6'):
                j+=6;
                break;
            case('7'):
                j+=3;
                break;
            case('8'):
                j+=7;
                break;
            case('9'):
                j+=6;
                break;
            case('0'):
                j+=6;
                break;
            }
            i++;
        }
        printf("%d leds\n",j);
    }
    return 0;
}
