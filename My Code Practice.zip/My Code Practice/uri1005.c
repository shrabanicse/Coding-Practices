#include<stdio.h>
int main()
{
    float a,b,c;
    scanf("%f %f",&a,&b);
    c=((a*3.5)+(b*7.5))/(3.5+7.5);
    printf("MEDIA = %0.5f\n",c);
    return 0;
}
/*#include<stdio.h>
int main()
{
    float a,b;
    scanf("%f %f",&a,&b);
    printf("MEDIA = %.5f\n",(a*3.5+b*7.5)/(3.5+7.5));
    return 0;
}*/
