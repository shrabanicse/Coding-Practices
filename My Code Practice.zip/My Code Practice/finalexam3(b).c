#include<stdio.h>
#include<string.h>
int main()
{
    char a[1000];
    int b,i;
    gets(a);
    b=strlen(a);
    for(i=0; i<b; i++)
    {
        if(a[i]=='a')
            printf("A");
        else if(a[i]=='A')
            printf("a");
        else if(a[i]=='e')
            printf("E");
        else if(a[i]=='E')
            printf("e");
        else if(a[i]=='i')
            printf("I");
        else if(a[i]=='I')
            printf("i");
        else if(a[i]=='o')
            printf("O");
        else if(a[i]=='O')
            printf("o");
        else if(a[i]=='u')
            printf("U");
        else if(a[i]=='U')
            printf("u");
        else if(a[i]>='0' && a[i]<='9')
            printf("%c",a[i]);
        else
            continue;
    }
    return 0;
}
