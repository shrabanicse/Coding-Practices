#include<stdio.h>
#include<math.h>
#include<string.h>


int main ()

{ char a[1000];
 int decimal=0,i,c=0;


  printf("Enter any hexadecimal number: ");
  gets (a);

int len = strlen(a);



   for (i=strlen(a)-1;i>=0;i--)
   {
       if (a[i]>='A' && a[i]<='Z')
       {
        decimal+=(a[i]-65+10)*pow(16,c);

       }

       else if (a[i]>'a' && a[i]<='z')
         {
             decimal+= (a[i]-97+10)*pow(16,c);

         }
       else if (a[i]>='0' && a[i]<='9')
        {
            decimal+= (a[i]-48)*pow(16,c);

        }

           c++;

         }
         printf ("decimal number is %d",decimal);
             return 0;
}
