# include <iostream >
# include <fstream >
# include <cstdlib >
using namespace std;

int main()
{
    ifstream in;
    ofstream out;
    in.open("file.txt" , std::ios_base::app);
    if(!in)
    {
        cout<<"file could not be opened!"<<endl;
        return 0;
    }
    else
    {
        cout<<"opened successfully"<<endl;
    }
    char ch[100];
    while(!in.eof())
    {
        in.getline(ch ,100);
        cout<<ch<<endl;
    }
    in.seekg(-3 , ios:: end);


    out.put('l');
    out.close();

    return 0;
}
