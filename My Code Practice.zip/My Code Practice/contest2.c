#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    printf("I Love you %d times\n",t);
    return 0;
}
