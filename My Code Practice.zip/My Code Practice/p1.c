#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    printf("Tourist\n");
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    return 0;
}
