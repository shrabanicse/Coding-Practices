#include    <stdio.h>

int         main ()

{
            int a=50 , b=60 , sum;

            sum=a+b;

            printf ("%d + %d = %d " , a, b, sum);

            return 0;
}
