#include<stdio.h>
void a(int *t)
{
    *t= *t-1;
}
int main()
{
    int n;
    scanf("%d",&n);
    a(&n);
    printf("%d",n);
    return 0;
}
