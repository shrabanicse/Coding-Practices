#include<stdio.h>
int main()
{
    int t,i,n;
    scanf("%d",&t);
    for(i=0; i<t; i++)
    {
        scanf("%d",&n);
        {
            if(n%2!= 0)
                printf("Team Gryffindor\n");
            else
                printf("Team Slytherin\n");
        }
    }
    return 0;
}
