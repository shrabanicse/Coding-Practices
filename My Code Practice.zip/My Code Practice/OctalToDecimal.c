//octal to binary
//binary to decimal
#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
    char a[1000],b[3000];
    int y,i,j=0,count=0,sum=0,mul,d;
    gets(a);
    y=strlen(a);
    for(i=0; i<y; i++)
    {
        if(a[i]=='0')
        {
            b[j]='0';
            b[j+1]='0';
            b[j+2]='0';
        }
        else if(a[i]=='1')
        {
            b[j]='0';
            b[j+1]='0';
            b[j+2]='1';
        }
        else if(a[i]=='2')
        {
            b[j]='0';
            b[j+1]='1';
            b[j+2]='0';
        }
        else if(a[i]=='3')
        {
            b[j]='0';
            b[j+1]='1';
            b[j+2]='1';
        }
        else if(a[i]=='4')
        {
            b[j]='1';
            b[j+1]='0';
            b[j+2]='0';
        }
        else if(a[i]=='5')
        {
            b[j]='1';
            b[j+1]='0';
            b[j+2]='1';
        }
        else if(a[i]=='6')
        {
            b[j]='1';
            b[j+1]='1';
            b[j+2]='0';
        }
        else if(a[i]=='7')
        {
            b[j]='1';
            b[j+1]='1';
            b[j+2]='1';
        }
        else
        {
            count=1;
            break;
        }
        j=j+3;
    }
    b[j]='\0';
    if(count==1)
        printf("Can't convert. Invalid octal number\n");
    else
    {
        puts(b);
        y=y*3;
        d=y;
        for(i=0; i<y; i++)
        {
            mul=(b[i]-'0')*pow(2,--d);
            sum=sum+mul;
        }
        printf("%d\n",sum);
    }
    return 0;
}

