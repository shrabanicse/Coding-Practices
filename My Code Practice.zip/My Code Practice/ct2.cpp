#include<iostream>
#include<cstring>

using namespace std;

void upper_case(char word)
{
    try
    {
        if(word>64 && word<91)
            throw word;

        cout<<word<<" "<<"is okay"<<endl;
    }
    catch(char c)
    {

        cout<<word<<" "<<"is an exception"<<endl;
    }
}
int main()
{
    string word;
    cin>>word;

    for(int i=0; i<word.size(); i++)
    {
        upper_case(word[i]);
    }
}
