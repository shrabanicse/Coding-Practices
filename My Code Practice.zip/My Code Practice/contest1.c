#include<stdio.h>
int main()
{
    int s,d,t;
    scanf("%d%d",&s,&d);
    t=s+d;
    printf("%d\n",t);
    return 0;
}
