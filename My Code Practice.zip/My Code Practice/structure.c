#include<stdio.h>
struct Student
{
    int id;
    char name[100];
    int intake;
    int section;
    char dept[50];
    char address[200];
    int mobile_number;
    char blood_group[5];
    char email[40];
};
int main()
{
    struct Student std[1000];
    for(int i=0; i<2; i++)
    {
        //printf("Enter an id for student: ");
        scanf("%d", &std[i].id);
        getchar();
        gets(std[i].name);
        scanf("%d %d", &std[i].intake, &std[i].section);
        getchar();
        gets(std[i].dept);
        gets(std[i].address);
        printf("Student's ID: %d\n", std[i].id);
    printf("Student's Name: %s\n", std[i].name);
    printf("Student's Intake: %d Section: %d\n", std[i].intake, std[i].section);
    printf("Student's Dept: %s\n", std[i].dept);
    printf("Student's Address: %s\n", std[i].address);
    }

    /* for(int j=0; j<2; j++)
    {
        printf("Student's ID: %d\n", std[j].id);
    printf("Student's Name: %s\n", std[j].name);
    printf("Student's Intake: %d Section: %d\n", std[j].intake, std[j].section);
    printf("Student's Dept: %s\n", std[j].dept);
    printf("Student's Address: %s\n", std[j].address);
    } */

    return 0;
}
