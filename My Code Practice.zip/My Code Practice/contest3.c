#include<stdio.h>
#include<string.h>
int main()
{
    int a[10000];
    int n,t,d,x,i,j;
    char y[10000][25],temp[25];
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        t=0;
        scanf("%d",&x);
        for(j=0; j<x; j++)
            scanf("%s %d",&y[j],&a[j]);
        scanf("%d %s",&d,&temp);
        printf("Case %d: ",i);
        for(j=0; j<x; j++)
        {
            if(strcmp(temp,y[j])==0)
            {
                if(a[j]<=d)
                    printf("Yesss\n");
                else if(a[j]<=d+5)
                    printf("Late\n");
                else printf("Do your own homework!\n");
                t=1;
                break;
            }
        }
        if(t==0)printf("Do your own homework!\n");
    }
    return 0;
}

