#include<stdio.h>
int main()
{
    int i,j,n;
    scanf("%d",&n);
    int m=n;
    for(i=1;i<n*2;i+=2)
    {
       for(int k=0;k<m*2-2;k++)
        printf(" ");
        m--;
        for(j=1;j<=i;j++)
        {

            printf("* ");
        }
        printf("\n");
    }
       return 0;
}

