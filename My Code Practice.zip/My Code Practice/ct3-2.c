#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
    char n[1000];
    FILE *fp;
    if ((fp = fopen("E:\\prog.txt","r")) == NULL)
    {
        printf("Opening file error!");
        exit(1);
    }
    fscanf(fp,"%s",n);
    strrev(n);
    printf("%s",n);
    fclose(fp);
    return 0;
}
