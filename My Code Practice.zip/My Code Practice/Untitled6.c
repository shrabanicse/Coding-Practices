#include<stdio.h>
#include<string.h>
int main()
{
    long long int a,b,c,d,e,i,l,leap_year,huluculu,bulukulu,nl=0;
    char s[100000];
    while(gets(s))
    {
        a=0,b=0,c=0,d=0,e=0,leap_year=0,huluculu=0,bulukulu=0,l=strlen(s);
        for(i=0; i<l; i++)
        {
            a=a*10+(s[i]-'0');
            a=a%4;
        }

        if(a==0)
        {
            for(i=0; i<l; i++)
            {
                b=b*10+(s[i]-'0');
                b=b%100;
            }
            if(b==0)
            {
                for(i=0; i<l; i++)
                {
                    c=c*10+(s[i]-'0');
                    c=c%400;
                }
                if(c==0)
                    leap_year=1;
            }
            else
                leap_year=1;
        }
        for(i=0; i<l; i++)
        {
            d=d*10+(s[i]-'0');
            d=d%15;
        }
        if(d==0)
            huluculu=1;
        if(leap_year==1)
        {
            for(i=0; i<l; i++)
            {
                e=e*10+(s[i]-'0');
                e=e%55;
            }
            if(e==0)
                bulukulu=1;
        }
        if(nl!=0)
            printf("\n");
        if(leap_year==1)
            printf("This is leap year.\n");
        if(huluculu==1)
            printf("This is huluculu festival year.\n");
        if(bulukulu==1)
            printf("This is bulukulu festival year.\n");
        if(leap_year==0 && huluculu==0 && bulukulu==0)
            printf("This is an ordinary year.\n");
        nl++;
    }
    return 0;
}
