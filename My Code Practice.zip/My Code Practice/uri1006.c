#include<stdio.h>
int main()
{
   double a,b,c,d;
   scanf("%lf%lf%lf",&a,&b,&c);
   d=(a/10*2)+(b/10*3)+(c/10*5);
   printf("MEDIA = %0.1lf\n",d);
   return 0;
}
