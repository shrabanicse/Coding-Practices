#include<stdio.h>
int main()
{
    int X,Y;
    scanf("%d %d",&X,&Y);
    int temp=X;
    X=Y;
    Y=temp;
    printf("%d %d %d\n",X,Y,abs(X-Y));
    return 0;
}
