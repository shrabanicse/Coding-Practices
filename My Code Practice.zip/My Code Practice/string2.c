#include<stdio.h>
#include<string.h>
int main()
{
    char a[1000],var,var1;
    int i,y,count=0,cou=0;
    gets(a);
    y=strlen(a);

    scanf("%c %c",&var1,&var);
    for(i=0;i<y;i++)
    {
        if(a[i]==var )
        count++;
        if(a[i]==var1)
        cou++;
    }


    //printf("%c",a[i]);
    //printf("%c",a[10]);
    printf("%d %d",cou,count);
    return 0;
}
