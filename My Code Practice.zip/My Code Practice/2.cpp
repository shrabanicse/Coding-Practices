#include <iostream>
#include <cmath>
#include <cstring>
#include <cstdlib>
using namespace std;

double calculateDisplacement (double v,double t)
{
    return v*t;
}
double calculateDisplacement (double u,double t,double a)
{
    return u*t+0.5*a*pow(t,2);
}
int main ()
{
    double displacement1, displacement2;
    displacement1 = calculateDisplacement(10,2);
    displacement2 = calculateDisplacement(0,2,1);

    cout<<"the car moves with constant velocity 10ms^-1, and the displacement in 2sec is"<<" "<< displacement1 <<"m."<<endl;
    cout<<"the car moves with constant acceleration 1ms^-2, started with velocity 0ms^-1 and the displacement in 2sec is"<<" "<< displacement2 <<"m."<<endl;
}
