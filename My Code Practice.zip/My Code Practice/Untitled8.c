#include<stdio.h>
int main()
{
    int t,i=0,n;
    scanf("%d",&t);
    for(i=1; i<=t; i++)
   {
       scanf("%d",&n);
        {
            if(n>0)
            {
                printf("%d is positive integer\n",n);
            }
            else if(n<0)
            {
                printf("%d is negative integer\n",n);
            }
            else
            {
                printf("%d is zero\n",n);
            }
        }
   }

    return 0;
}
