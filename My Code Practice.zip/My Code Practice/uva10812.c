#include<stdio.h>
#include<math.h>
int main()
{
    int sum,sub,T;
    long long int score1,score2;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d %d",&sum,&sub);
             if(sub>sum)
                printf("impossible\n");
             else{
                  score2=(sum-sub)/2;
                  score1=sub+score2;
                  if(score1+score2==sum&&abs(score1-score2)==sub)
                     printf("%lld %lld\n",score1,score2);
                  else
                     printf("impossible\n");
             }
     }
     return 0;
}
