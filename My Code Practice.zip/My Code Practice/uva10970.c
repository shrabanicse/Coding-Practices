#include<stdio.h>
int main()
{
    int M,N,result;
    while(scanf("%d%d",&M,&N)!=EOF)
    {
        result=((M*N)-1);
        printf("%d\n",result);
    }
    return 0;

}
