#include<stdio.h>
int main()
{
    int count,firstnum,secondnum,i;
    scanf("%d",&count);
    for(i=0; i<count; i++)
    {
        scanf("%d%d",&firstnum,&secondnum);
        if(firstnum>secondnum)
        {
            printf(">\n");
        }
        else if(firstnum<secondnum)
        {
            printf("<\n");
        }
        else
        {
            printf("=\n");
        }
    }
    return 0;
}
