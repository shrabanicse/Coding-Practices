#include<stdio.h>
int main()
{
    double
    s=4000,
    u=20,
    v=33,
    t;
    t=2*s/(u+v);
    printf("The time to cover the distance is=%0.2lf\n",t);
    return 0;
}
