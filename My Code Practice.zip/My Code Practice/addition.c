#include<stdio.h>
int main()
{
    int a,b;
    printf("Input two numbers:\n");
    scanf("%d%d",&a,&b);
    int sum=a+b;
    printf("Summation of %d and %d is %d\n",a,b,sum);
    return 0;
}
