#include<fstream>
#include <iostream>

using namespace std;

int main()
{
    ifstream f("in.txt");

    f.seekg(0, f.end);
    int len = f.tellg();

    char c;
    cout<< len<< endl;
    /*{
        f.seekg(len, f.beg);
        f >> c;
        cout << c;

    */
    return 0;
}
