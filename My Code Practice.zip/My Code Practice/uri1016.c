#include<stdio.h>
int main()
{
    int distance;
    scanf("%d",&distance);
    printf("%d minutos\n",(2*distance));
    return 0;
}
