#include<stdio.h>
int main()
{
    printf("reading all the problems\n");
    return 0;
}
