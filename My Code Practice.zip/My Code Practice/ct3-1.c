#include <stdio.h>
void factorial(int n,int *m)
{
    int i;
    *m=1;
    for(i=1; i<=n; i++)
        *m=*m*i;
}
int main()
{
    int f,num;
    scanf("%d",&num);
    factorial(num,&f);
    printf("%d\n",f);
    return 0;
}
