#include<stdio.h>
int main()
{
    int d,h;
    double r,v;
    scanf("%d%d",&d,&h);
    r=d/2.0;
    v=3.14*r*r*h;
    printf("%.2lf cm^3\n",v);
    return 0;
}
