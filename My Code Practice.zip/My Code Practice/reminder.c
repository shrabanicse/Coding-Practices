#include<stdio.h>
int main()
{
    int a,b;
    printf("Input two numbers:\n");
    scanf("%d%d",&a,&b);
    int rem=a%b;
    printf("The reminder is %d\n",rem);
    return 0;
}

