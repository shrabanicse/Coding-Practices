#include<stdio.h>
int main()
{
    int sum,a=0,b=1,n,i;
    printf("Enter n:");
    scanf("%d",&n);
    if(n==1)
        printf("%d",a);
    else if (n==2)
        printf("%d %d",a,b);
    else{
          printf("%d %d",a,b);
    for(i=0;i<n-2;i++)
    {
        sum=a+b;
        a=b;
        b=sum;
        printf(" %d",sum);
    }

    }
    return 0;

}
