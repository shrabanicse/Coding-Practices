#include<stdio.h>
int main()
{
    int T,N;
    scanf("%d",&T);
    int c=1,i;
    while(T--){
        scanf("%d",&N);
        int sum=0,temp;
        for(i=0;i<N;i++){
            scanf("%d",&temp);
            if(temp>=0) sum+=temp;
        }
        printf("Case %d: %d\n",c++,sum);
    }
    return 0;
}
