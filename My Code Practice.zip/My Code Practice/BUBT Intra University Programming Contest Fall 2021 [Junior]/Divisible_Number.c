#include<stdio.h>
#include<string.h>
int main()
{
    char a[1010],b[10];
    int i,j,T,s,sum,p;
    scanf("%d",&T);
    gets(b);
    for(i=0; i<T; i++)
    {
        p=0;
        gets(a);
        s=strlen(a);
        sum=0;
        if((a[s-1]-48)%2==0)
        {
            for(j=0; j<s; j++)
            {
                sum=sum+(a[j]-48);
            }
            if(sum%9==0)
                p=1;
        }
        if(p==1)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}
