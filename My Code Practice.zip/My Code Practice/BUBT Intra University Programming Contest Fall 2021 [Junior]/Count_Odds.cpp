#include<iostream>
using namespace std;
int main()
{
    long long int F,N;
    int countOdd=0;
    cin>>F;
    cin>>N;
       for(int i=F; i<=N; i++)
    {
        if(i%2 == 1)
            countOdd++;
    }
    cout<<countOdd<<endl;
    return 0;
}
