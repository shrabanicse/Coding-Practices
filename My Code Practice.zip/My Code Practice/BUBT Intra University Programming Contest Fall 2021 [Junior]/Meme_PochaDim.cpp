#include<bits/stdc++.h>
using namespace std;
int main()
{
    string f1,f2,f3,f4,f5;
    cin>>f1;cin>>f2;cin>>f3;cin>>f4;cin>>f5;
    if(f1.size()==5 && f2.size()==5 && f3.size()==5 && f4.size()==5 && f5.size()==5)
    {
        cout<<"Mim"<<'\n';
    }
    else
    {
        cout<<"Pocha Dim"<<'\n';
    }
    return 0;
}
