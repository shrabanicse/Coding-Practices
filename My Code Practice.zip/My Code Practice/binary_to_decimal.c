#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
    char b[1000];
    int y,i,sum=0,mul;
    gets(b);
    y=strlen(b);
    int d=y;
    for(i=0; i<y; i++)
    {
        mul=(b[i]-'0')*pow(2,--d);
        sum=sum+mul;
    }
    printf("%d\n",sum);
    return 0;
}
