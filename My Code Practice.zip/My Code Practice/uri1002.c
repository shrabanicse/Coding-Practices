#include<stdio.h>
int main()
{
    double R,A;
    scanf("%lf",&R);
    A=(3.14159*R*R);
    printf("A=%0.4lf\n",A);
    return 0;
}
