#include<stdio.h>
#include<math.h>
int sum(int P,int Q)
{
    printf("P+Q = %d\n",P+Q);
}
int sub(int P,int Q)
{
    printf("P-Q = %d\n",P-Q);
}
int mul(int P,int Q)
{
    printf("P*Q = %d\n",P*Q);
}
int div(int P,int Q)
{
    printf("P/Q = %0.1lf\n",(double)P/Q);
}
int min(int M,int N,int O)
{
    if(M<N)
    {
        if(M<O)
        {
            return M;
        }
    }
    else if(N<M)
    {
        if(N<O)
        {
            return N;
        }
    }
    return O;
}
int main()
{
    int P,Q,R;
    scanf("%d %d",&P,&Q);
    sum(P,Q);
    sub(P,Q);
    mul(P,Q);
    div(P,Q);
    scanf("%d",&R);
    printf("min = %d",min(P,Q,R));
    return 0;
}

