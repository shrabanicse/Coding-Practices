#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;

class str{
    char *p;
    int len;
public:
    str(){
        cout<<"constructing object!"<<endl;
    }
    str(char *s){
        cout<<"constructing object!"<<endl;
        len = strlen(s);
        p = (char*) malloc(len+1);
        strcpy(p, s);
    }
    str(const str &f){
        cout<<"constructing object using copy constructor!"<<endl;
        int size = strlen(f.p)+1;
        p = new char[size];
        strcpy(p,f.p);
    }
    ~str(){
        cout<<"destructing object!"<<endl;
        free(p);
    }
    void show(){
        cout<<p<<endl;
    }
    friend void function_(str ob);
};

void function_(str ob){
    cout<<"from function : "<<ob.p<<endl;
}

int main(){
    str ob("hello world!");
    function_(ob);
    ob.show();
}
