#include<stdio.h>
#include<string.h>
int main()
{
    char hexa[20];
    {
        printf("Enter a hexadecimal number: ");
        gets(hexa);
        int count=strlen(hexa)-1;
        int sum=0,x;
        for(int i=0; hexa[i]!='\0'; i++)
        {

            if(hexa[i]>='0' && hexa[i]<='9')
            {
                x=hexa[i]-48;
            }
            else if(hexa[i]>='a' && hexa[i]<='f')
            {
                x=hexa[i]-97+10;
            }
            else if(hexa[i]>='A' && hexa[i]<='F')
            {
                x=hexa[i]-65+10;
            }
            sum += x*pow(16,count);
            count--;
        }
        printf("The decimal number of %s is: %d\n",hexa,sum);
        printf("\n");
    }
    return 0;
}

