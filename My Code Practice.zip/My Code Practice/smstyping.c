#include<stdio.h>
#include<string.h>
int main()
{
    char a[1000];
    int j,t,i,y,sum=0;
    scanf("%d",&t);
    gets(a);
    for(j=0; j<t; j++)
    {
        gets(a);
        y=strlen(a);
        for(i=0; i<y; i++)
        {
            if(a[i]=='a' || a[i]=='d' || a[i]=='g' || a[i]=='j' || a[i]=='m' || a[i]=='p'  || a[i]=='t' || a[i]=='w' || a[i]==' ')
                sum=sum+1;
            else if(a[i]=='b' || a[i]=='e' || a[i]=='h' || a[i]=='k' || a[i]=='n' || a[i]=='q'  || a[i]=='u' || a[i]=='x')
                sum=sum+2;
            else if(a[i]=='c' || a[i]=='f' || a[i]=='i' || a[i]=='l' || a[i]=='o' || a[i]=='r'  || a[i]=='v' || a[i]=='y')
                sum=sum+3;
            else
                sum=sum+4;

        }
        printf("Case #%d: %d\n",j+1,sum);
        sum=0;

    }


    return 0;
}
