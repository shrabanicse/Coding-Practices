#include<stdio.h>
int main()
{
    int n=5;
    while(n++<7)
    {
        printf("%d\n",n++);
    }
    return 0;
}
