#include<stdio.h>
#include<math.h>
int main()
{
    int n,i;
    long long int a,b;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        scanf("%lld",&b);
        if(b%2!=0)
            printf("Case %d: Impossible\n",i);
        else
        {
            a=1;
            while(b%2==0)
            {
                a=a*2;
                b=b/2;
            }
            printf("Case %d: %lld %lld\n",i,b,a);
        }
    }
    return 0;
}
