#include<stdio.h>
#include<string.h>
int main()
{
    char a[1000],b[1000];
    int i,y,j=0;
    gets(a);

    y=strlen(a);
    for (i=y-1; i>=0; i--)

    {
        b[j]=a[i];
        j++;
    }
    b[j]='\0';
    puts(b);
    //printf("%c",a[i]);
    return 0;
}




/*#include<stdio.h>
#include<string.h>
int main()
{
    char a[1000],b[1000];

    int i;
    gets(a);
    int y=strlen(a);
       for (i=0;i<y;i++)
       {
           b[i]=a[i];
       }

        puts(b);

    return 0;
}
*/

/*#include<stdio.h>
#include<string.h>
int main()
{
    char a[1000],b[1000];
    gets(a);
    strcpy(b,a);
    strrev(a);
    puts(a);
    puts(b);
    return 0;
}
*/

