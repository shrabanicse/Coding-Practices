#include<stdio.h>
int main()
{
    double Num;
    printf("Enter your number:\n");
    scanf("%lf",&Num);
    if(80<=Num && Num<=100)
        printf("Your grade is A+");
    else if(75<=Num && Num<80)
        printf("Your grade is A");
    else if(70<=Num && Num<75)
        printf("Your grade is A-");
    else if(65<=Num && Num<70)
        printf("Your grade is B+");
    else if(60<=Num && Num<65)
        printf("Your grade is B");
    else if(55<=Num && Num<60)
        printf("Your grade is B-");
    else if(50<=Num && Num<55)
        printf("Your grade is C+");
    else if(45<=Num && Num<50)
        printf("Your grade is C-");
    else if(40<=Num && Num<45)
        printf("Your grade is D");
    else if(0<=Num && Num<40)
        printf("Your grade is F");
    else
        printf("Please enter valid number");

    return 0;
}
