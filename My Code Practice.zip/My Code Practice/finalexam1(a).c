#include<stdio.h>
int main()
{
    char str[1000]="Hello! Do you love Programming?";//declared variable str replacing s
    char *ptr;
    ptr= &str;//removed * from ptr and added &sign before str
    *ptr+=7;//added pointer sign before ptr
    printf("%s\n", ptr);//removed pointer sign from ptr
    str[6]= '\0';
    ++*ptr;//added * before ptr
    printf("%s\n", ptr);//removed * from ptr
    --*ptr;//replaced ptr--
    printf("%s\n", ptr);//replaced str into ptr

    return 0;
}
