#include<stdio.h>
#include<string.h>
int main()
{
    char a[100][100];
    int j,y;
    for(j=0;j<10;j++)
    scanf("%s",a[j]);
    for(j=0;j<10;j++)
    printf("%s ",a[j]);
    y=strlen(a[0]);
    printf("%d",y);
    return 0;
}
