#include<stdio.h>
#include<string.h>
int main()
{
    FILE *a,*b;
    char c[1000];
    a=fopen("E:\\prog.txt","r");
    b=fopen("E:\\prog2.txt","w");
    if (!a)
        return 1;
    while (fgets(c,1000,a)!=NULL)
    {
        strrev(c);
        fputs(c,b);
    }
    printf("Write in a text file successfully!!");
    fclose(a);
    fclose(b);
    return 0;
}
