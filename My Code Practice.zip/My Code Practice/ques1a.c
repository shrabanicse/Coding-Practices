#include<stdio.h>
int main()
{
    int i,j,k;
    k=i+j;
    scanf("%d%d",&i,&j);

    printf("sum = %d",k);
    return 0;
}
