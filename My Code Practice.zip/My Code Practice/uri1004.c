#include<stdio.h>
int main()
{
    int a,b,c;
    scanf("%d %d",&a,&b);
    c=a*b;
    printf("PROD = %d\n",c);
    return 0;
}
