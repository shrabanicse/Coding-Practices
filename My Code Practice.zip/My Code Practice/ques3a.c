#include<stdio.h>
#include<math.h>
int main()
{
    int a[1000];
    int X,Y,m,n=0;

    scanf("%d %d",&X,&Y);
    if(X>Y)
    {
        int temp=X;
        X=Y;
        Y=temp;
    }
    int Sum=0;
    for(m=X; m<=Y; m++)
    {
        if(m%3==0)
        {
            if(m%5==0)
            {
                if(m%2==1)
                {
                    a[n]=m;
                    Sum+=m;
                    n++;
                }
            }
        }
    }
    printf("%d and ",Sum);
    for(m=0; m<n; m++)
    {
        printf("%d ",a[m]);
    }
    return 0;
}
