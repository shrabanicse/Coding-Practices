#include<stdio.h>
main()
{
   int a,b;
   printf("Input two numbers:\n");
   scanf("%d%d",&a,&b);
   int mult=a*b;
   printf("Multiplication of %d and %d is %d\n",a,b,mult);
   return 0;
}
