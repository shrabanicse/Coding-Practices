#include<stdio.h>
int main()
{
    int x,i;
    scanf("%d",&x);
    printf("W");
    for(i=0; i<x; i++)
    {
        printf("o");
    }
    printf("w");

    return 0;
}

