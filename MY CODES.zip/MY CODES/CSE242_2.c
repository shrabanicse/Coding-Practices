#include<stdio.h>
#include<string.h>
int main()
{
    char a[5000],c[100];
    int b,i;
    {
        gets(a);
        b=strlen(a);
        for(i=0; i<b; i++)
        {
            if(a[i]=='a')
            {
                printf("ba");
            }
            else if(a[i]=='e')
            {
                printf("fe");
            }
            else if(a[i]=='i')
            {
                printf("ji");
            }
            else if(a[i]=='o')
            {
                printf("po");
            }
            else if(a[i]=='u')
            {
                printf("vu");
            }
            else
            {
                printf("%c", a[i]);
            }
        }
    }
    return 0;
}
/* if(a[i]=='A')
            {
                printf("BA");
            }
            else if(a[i]=='E')
            {
                printf("FE");
            }
            else if(a[i]=='I')
            {
                printf("JI");
            }
            else if(a[i]=='O')
            {
                printf("PO");
            }
            else if(a[i]=='U')
            {
                printf("VU");
            }
            */
