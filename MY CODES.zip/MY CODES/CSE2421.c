#include <stdio.h>
int main()
{
    int i,j,k=0,q,primes[100000],p[100000],n,b=0,m,count=0;
    for(i = 2; i<=100000; i++)
        primes[i] = i;
    i = 2;
    while ((i*i) <= 100000)
    {
        if (primes[i] != 0)
        {
            for(j=2; j<100000; j++)
            {
                if (primes[i]*j > 100000)
                    break;
                else
                    primes[primes[i]*j]=0;
            }
        }
        i++;
    }
    for(i = 2; i<=100000; i++)
    {
        if (primes[i]!=0)
        {
            p[k]=primes[i];
            k++;
        }
    }
    scanf("%d",&n);
    m=n;
    for(q=0; q<k; q++)
    {
        if(p[q]==n)
        {
            b=1;
        }
    }
    if(b==1)
    {
        for(q=0; m!=0; q++)
        {
            m=m/10;
            count++;
        }
        if(count==1)
            printf("00%d00",n);
        else if(count==2)
            printf("00%d0",n);
        else if(count==3)
            printf("0%d0",n);
        else if(count==4)
            printf("0%d",n);
        else
            printf("%d",n);
    }
    else
        printf("%d",n);
    return 0;
}
