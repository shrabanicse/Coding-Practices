#include <stdio.h>
#define MAX_SIZE 100

int main()
{
    char c[MAX_SIZE];
    int digit = 0;

    printf("Enter a line of characters>");
    gets(c);

    for (int i = 0; i < MAX_SIZE; i++)
    {
        if (c[i] == '\n') break; // this line checks to see if we have reached the end of the line. If so, exit the for loop (thats what the "break" statment does.)

        //if (isdigit(c[i])) // uncomment this line and comment or delete the one below to use a much easier method to check if a character is a digit.
        if (c [i]>= '0' && c[i] <= '9')
        {
            digit++;
        }
    }

    printf("%d\n", digit);
    return 0;
}
