#include <iostream>
#include <stack>
using namespace std;
stack <char> s;
int main()
{
    string st;
    cin>>st;
    int n=st.size(),j;
    for(j=0; j<n; j++)
    {
        s.push(st[j]);
    }
    int f=0;
    while(!s.empty())
    {
        if(s.top()>='0' && s.top()<='9')
        {
            ++f;
        }
        s.pop();
    }
    cout<<f<<endl;
    return 0;
}
