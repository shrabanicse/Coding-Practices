#include<stdio.h>
void main()
{
    char s[30];
    int i=2,a=0;
    printf("Enter Input String: ");
    gets(s);
      int len = strlen(s);
    if(s[0]=='/')
    {
        if(s[1]=='/')
            printf("Single line comment");
        else if(s[1]=='*')
        {
            for(i=2; i<=30; i++)
            {
                if(s[i]=='*' && s[i+1]=='/')
                {
                    printf("Multiple line comment");
                    a=1;
                    break;
                }
                else continue;
            }
            if(a==0)
                printf("Not a comment");
        }
        else
            printf("Not a comment");
    }
    else
        printf("Not a comment");
}
