#include<stdio.h>
#include<string.h>
int main()
{
    char a[5000],c[100];
    int count=0;
    int b,t,i,j;
    for(j=0; j<t; j++)
    {
        gets(a);
        b=strlen(a);
        for(i=0; i<b; i++)
        {
            if((a[i]>='0')  && (a[i]<='9'))
            {
                count++;
            }

            else
                continue;
        }
        printf("%d", count);
    }
    return 0;
}

