#include <stdio.h>

int collatz_sequence_length(int n)
{
    int length = 1;
    while (n != 1)
    {
        if (n % 2 == 0)
            n = n / 2;
        else
            n = 3 * n + 1;
        length++;
    }
    return length;
}

int main()
{
    int n, m;
    while (scanf("%d%d", &n, &m) == 2 && n > 0 && m > 0)
    {
        int max_length = 0;
        int i;
        printf("%d %d ", n, m);
        if (n > m)
        {
            int temp = n;
            n = m;
            m = temp;
        }
        for (i = n; i <= m; i++)
        {
            int length = collatz_sequence_length(i);
            if (length > max_length)
                max_length = length;
        }
        printf("%d\n", max_length);
    }
    return 0;
}
