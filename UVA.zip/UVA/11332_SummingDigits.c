#include <stdio.h>
int main()
{
    int f;
    long long int n;
    while(scanf("%lld",&n)==1)
    {
        if(n==0)
            break;
        f=0;
        while(1)
        {
            while(n!=0)
            {
                f=f+(n%10);
                n=n/10;
            }
            if(f/10==0)
                break;
            else
            {
                n=f;
                f=0;
            }
        }
        printf("%d\n",f);
    }
    return 0;
}
